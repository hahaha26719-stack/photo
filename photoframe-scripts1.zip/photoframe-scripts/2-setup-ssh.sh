#!/bin/bash
#
# 2-setup-ssh.sh
#
# Run this ON THE DEVICE (physical keyboard+HDMI, logged in as root).
# Installs/enables SSH and prints the IP address(es) to connect to from
# Windows, e.g.:
#   ssh pi@<ip-shown-below>
# using PowerShell's built-in ssh client, PuTTY, or Windows Terminal.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run this as root (sudo -i, or 'sudo bash $0')." >&2
    exit 1
fi

echo "==> Installing/enabling SSH server"
apt update
apt install -y openssh-server
systemctl enable --now ssh

if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
    ufw allow OpenSSH
fi

echo
echo "==> SSH is running:"
systemctl is-active ssh

echo
echo "==> Network addresses:"
ip -4 -o addr show scope global | awk '{print "  " $2 ": " $4}'

echo
echo "==> Hostname:"
hostname

echo
echo "-----------------------------------------------------------------"
echo "From Windows, connect with (PowerShell, Windows Terminal, or"
echo "PuTTY using the same host/user):"
echo
for ip in $(ip -4 -o addr show scope global | awk '{print $4}' | cut -d/ -f1); do
    echo "    ssh pi@$ip"
done
echo
echo "First login: use the 'pi' account created in 1-setup-after-sd-boot.sh."
echo "If that script hasn't been run yet, log in as root for now."
echo "-----------------------------------------------------------------"
