#!/bin/bash
#
# 1-setup-after-sd-boot.sh
#
# Run this ON THE DEVICE (logged in as root, keyboard+HDMI or SSH) right
# after the very first boot from the freshly flashed SD card.
#
# It does everything from "Parts 2-6, 8" of the setup guide in one pass:
#   - creates the 'pi' user
#   - apt update/upgrade
#   - (optional, confirmed) clones the running system from SD to eMMC
#   - installs Xorg + feh + unclutter, sets auto-login -> startx
#   - deploys slideshow.sh + controller.sh
#   - installs + enables the slideshow.service / controller.service units
#   - installs the midnight "next" cron job
#   - adds a swapfile (512MB RAM is tight)
#
# Safe to re-run: every step checks for existing state first.
#
# NOTE ON eMMC CLONE: this is the one destructive step (dd of a whole
# block device). The script always shows `lsblk` and requires you to type
# the exact target device name back before it touches anything. If you
# just want the eMMC clone skipped (e.g. you already did it, or you're
# fine running from SD for now), answer 'n' when asked.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run this as root (sudo -i, or 'sudo bash $0')." >&2
    exit 1
fi

log() { echo -e "\n==> $*"; }

# ---------------------------------------------------------------------
log "Step 1/8: create the 'pi' user"
# ---------------------------------------------------------------------
if id pi &>/dev/null; then
    echo "User 'pi' already exists, skipping."
else
    adduser pi
    usermod -aG sudo,video,audio,tty pi
    echo "Created 'pi' and added to sudo,video,audio,tty."
fi

# ---------------------------------------------------------------------
log "Step 2/8: apt update && full-upgrade"
# ---------------------------------------------------------------------
apt update && apt full-upgrade -y

# ---------------------------------------------------------------------
log "Step 3/8: optional eMMC clone"
# ---------------------------------------------------------------------
read -rp "Clone the running system from SD to the internal eMMC now? [y/N] " do_clone
if [[ "${do_clone,,}" == "y" ]]; then
    echo
    lsblk -o NAME,SIZE,TYPE,MOUNTPOINT
    echo
    echo "Above: identify the SD card (larger, has the running root '/')"
    echo "and the eMMC (usually ~7-8GB, e.g. /dev/mmcblk1 or /dev/mmcblk2)."
    read -rp "Type the eMMC device path exactly (e.g. /dev/mmcblk1): " emmc_dev
    root_src="$(findmnt -n -o SOURCE / | sed -E 's/p?[0-9]+$//')"

    if [[ ! -b "$emmc_dev" ]]; then
        echo "ERROR: $emmc_dev is not a block device. Aborting clone (rest of script continues)." >&2
    elif [[ "$emmc_dev" == "$root_src" ]]; then
        echo "ERROR: that's the device you're currently booted from. Refusing to dd onto it." >&2
    else
        echo
        echo "About to run:  dd if=$root_src of=$emmc_dev bs=4M status=progress conv=fsync"
        read -rp "Type the device path again to CONFIRM (irreversible): " confirm_dev
        if [[ "$confirm_dev" == "$emmc_dev" ]]; then
            dd if="$root_src" of="$emmc_dev" bs=4M status=progress conv=fsync
            sync
            fdisk -l "$emmc_dev"

            boot_part="${emmc_dev}p1"
            [[ -b "$boot_part" ]] || boot_part="${emmc_dev}1"
            mkdir -p /mnt/emmcboot
            mount "$boot_part" /mnt/emmcboot
            envfile="/mnt/emmcboot/armbianEnv.txt"
            [[ -f "$envfile" ]] || envfile="/mnt/emmcboot/uEnv.txt"
            if [[ -f "$envfile" ]]; then
                echo "Current rootdev line in $envfile:"
                grep -i rootdev "$envfile" || echo "(no rootdev line found)"
                echo "Edit it now to point at ${emmc_dev}p1 if it doesn't already."
                nano "$envfile"
            else
                echo "Could not find armbianEnv.txt/uEnv.txt on $boot_part — edit boot config manually."
            fi
            umount /mnt/emmcboot

            echo
            echo "Clone done. Try 'sudo armbian-config' -> System -> Install/Update the"
            echo "bootloader (to be sure U-Boot is on eMMC too), then power off, remove"
            echo "the SD card, and power back on to confirm it boots from eMMC."
        else
            echo "Confirmation didn't match — skipping clone."
        fi
    fi
else
    echo "Skipping eMMC clone."
fi

# ---------------------------------------------------------------------
log "Step 4/8: display stack (Xorg + feh + unclutter)"
# ---------------------------------------------------------------------
apt install -y xserver-xorg xinit feh unclutter x11-xserver-utils imagemagick

mkdir -p /home/pi/photos
if [[ ! -f /home/pi/.xinitrc ]]; then
    cat > /home/pi/.xinitrc <<'EOF'
#!/bin/sh
xset -dpms       # disable DPMS power-saving blanking
xset s off        # disable screensaver
xset s noblank
exec sleep infinity   # keep X alive; slideshow.service drives feh separately
EOF
    chmod +x /home/pi/.xinitrc
fi
chown pi:pi /home/pi/.xinitrc

mkdir -p /etc/systemd/system/getty@tty1.service.d
cat > /etc/systemd/system/getty@tty1.service.d/override.conf <<'EOF'
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin pi --noclear %I $TERM
EOF

if ! grep -q 'startx' /home/pi/.bash_profile 2>/dev/null; then
    cat >> /home/pi/.bash_profile <<'EOF'
if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
    startx
fi
EOF
fi
chown pi:pi /home/pi/.bash_profile

# graphical.target needs to actually be reached for slideshow.service
# (WantedBy=graphical.target) to ever start on boot — this Armbian image
# defaults to multi-user.target, so switch it.
systemctl set-default graphical.target

# ---------------------------------------------------------------------
log "Step 5/8: deploy slideshow.sh + controller.sh"
# ---------------------------------------------------------------------
cat > /home/pi/slideshow.sh <<'SLIDESHOW_EOF'
#!/bin/bash
#
# slideshow.sh — launches feh full-screen against a single symlink.
# controller.sh (separate service) owns repointing that symlink and
# telling feh to redraw via feh's own --control-pipe ("reload"), in
# response to "next" / "skip" commands sent to /tmp/frame_ctl.
# feh itself is never killed or restarted — no flicker.

set -euo pipefail

PHOTO_DIR="/home/pi/photos"
LINK_DIR="/home/pi/slideshow_link"
CURRENT_LINK="$LINK_DIR/current.jpg"
STATE_FILE="/home/pi/.slideshow_current"   # filename of the last-shown real photo
PIPE="/tmp/feh_pipe"
LOGFILE="/var/log/slideshow.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOGFILE"
}

mkdir -p "$PHOTO_DIR" "$LINK_DIR"

if [[ -p "$PIPE" ]]; then
    log "Control pipe already exists at $PIPE"
elif [[ -e "$PIPE" ]]; then
    log "ERROR: $PIPE exists and is not a FIFO. Removing and recreating."
    rm -f "$PIPE"
    mkfifo "$PIPE"
else
    mkfifo "$PIPE"
    log "Created control pipe at $PIPE"
fi
chmod 660 "$PIPE"

unclutter -idle 0.1 -root &

while [[ -z "$(find "$PHOTO_DIR" -maxdepth 1 -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) -print -quit)" ]]; do
    log "No photos found yet in $PHOTO_DIR — waiting..."
    sleep 5
done

# --- Initialize the symlink on boot/first run: resume where we left off ---
if [[ ! -L "$CURRENT_LINK" ]]; then
    target=""
    if [[ -f "$STATE_FILE" ]]; then
        last="$(cat "$STATE_FILE")"
        [[ -f "$PHOTO_DIR/$last" ]] && target="$PHOTO_DIR/$last"
    fi
    if [[ -z "$target" ]]; then
        target="$(find "$PHOTO_DIR" -maxdepth 1 -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) | sort | head -n1)"
    fi
    ln -sf "$target" "$CURRENT_LINK"
    log "Initialized $CURRENT_LINK -> $(readlink "$CURRENT_LINK")"
fi

log "Starting feh on $CURRENT_LINK"

exec feh \
    --fullscreen \
    --hide-pointer \
    --auto-zoom \
    --control-pipe "$PIPE" \
    --no-menus \
    --quiet \
    "$CURRENT_LINK"
SLIDESHOW_EOF

cat > /home/pi/controller.sh <<'CONTROLLER_EOF'
#!/bin/bash
#
# controller.sh — owns /tmp/frame_ctl. Understands two commands:
#   next  -> advance to the next photo in sorted-filename order (wraps
#            after the last one). Robust to gaps left by web-UI deletes.
#   skip  -> show the black image (does NOT consume a slot in the
#            sequence; the next "next" resumes from where it left off)
#
# On each command it repoints the CURRENT_LINK symlink, then writes
# "reload" into feh's own --control-pipe so feh redraws in-process.
# feh is never killed or restarted.

set -euo pipefail

PHOTO_DIR="/home/pi/photos"
BLACK_IMAGE="/home/pi/black/black.jpg"
CURRENT_LINK="/home/pi/slideshow_link/current.jpg"
STATE_FILE="/home/pi/.slideshow_current"   # stores the last real photo FILENAME
FRAME_CTL="/tmp/frame_ctl"
FEH_PIPE="/tmp/feh_pipe"
LOGFILE="/var/log/slideshow.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [controller] $*" >> "$LOGFILE"
}

mkdir -p "$PHOTO_DIR" "$(dirname "$BLACK_IMAGE")" "$(dirname "$CURRENT_LINK")"

if [[ ! -f "$BLACK_IMAGE" ]]; then
    if command -v convert >/dev/null 2>&1; then
        convert -size 1920x1080 xc:black "$BLACK_IMAGE"
        log "Generated black image at $BLACK_IMAGE"
    else
        log "ERROR: no black.jpg and ImageMagick not installed. Place a black image at $BLACK_IMAGE manually."
    fi
fi

if [[ ! -p "$FRAME_CTL" ]]; then
    [[ -e "$FRAME_CTL" ]] && rm -f "$FRAME_CTL"
    mkfifo "$FRAME_CTL"
    log "Created $FRAME_CTL"
fi
chmod 660 "$FRAME_CTL"

reload_feh() {
    if [[ -p "$FEH_PIPE" ]]; then
        echo "reload" > "$FEH_PIPE"
    else
        log "WARNING: $FEH_PIPE not found — is slideshow.service running?"
    fi
}

do_next() {
    mapfile -t files < <(find "$PHOTO_DIR" -maxdepth 1 -type f \
        \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) | sort)
    local total="${#files[@]}"
    if [[ "$total" -eq 0 ]]; then
        log "No photos in $PHOTO_DIR — ignoring 'next'"
        return
    fi

    local last="" idx=-1
    [[ -f "$STATE_FILE" ]] && last="$(cat "$STATE_FILE")"

    if [[ -n "$last" ]]; then
        for i in "${!files[@]}"; do
            [[ "${files[$i]}" == "$PHOTO_DIR/$last" ]] && idx="$i" && break
        done
    fi

    local next_idx=$(( (idx + 1) % total ))
    local next_file="${files[$next_idx]}"

    ln -sf "$next_file" "$CURRENT_LINK"
    basename "$next_file" > "$STATE_FILE"
    log "next -> $(basename "$next_file") ($((next_idx + 1))/$total)"
    reload_feh
}

do_skip() {
    ln -sf "$BLACK_IMAGE" "$CURRENT_LINK"
    log "skip -> black image (sequence position unchanged)"
    reload_feh
}

log "Controller listening on $FRAME_CTL"

exec 3<>"$FRAME_CTL"
while read -r cmd <&3; do
    case "$cmd" in
        next) do_next ;;
        skip) do_skip ;;
        "")   : ;;
        *)    log "Unknown command: '$cmd' (expected 'next' or 'skip')" ;;
    esac
done
CONTROLLER_EOF

chmod +x /home/pi/slideshow.sh /home/pi/controller.sh
chown pi:pi /home/pi/slideshow.sh /home/pi/controller.sh

# ---------------------------------------------------------------------
log "Step 6/8: systemd services"
# ---------------------------------------------------------------------
cat > /etc/systemd/system/slideshow.service <<'EOF'
[Unit]
Description=Fullscreen feh photo slideshow
After=graphical.target network-online.target
Wants=network-online.target
Requisite=graphical.target

[Service]
Type=simple
User=pi
Group=pi
Environment=DISPLAY=:0
Environment=XAUTHORITY=/home/pi/.Xauthority
ExecStartPre=/bin/sh -c 'mkdir -p /home/pi/photos'
ExecStart=/home/pi/slideshow.sh
Restart=on-failure
RestartSec=5
StandardOutput=append:/var/log/slideshow.log
StandardError=append:/var/log/slideshow.log

[Install]
WantedBy=graphical.target
EOF

cat > /etc/systemd/system/controller.service <<'EOF'
[Unit]
Description=Photo frame controller (next/skip FIFO)
After=slideshow.service
Requires=slideshow.service

[Service]
Type=simple
User=pi
Group=pi
ExecStart=/home/pi/controller.sh
Restart=on-failure
RestartSec=5
StandardOutput=append:/var/log/slideshow.log
StandardError=append:/var/log/slideshow.log

[Install]
WantedBy=graphical.target
EOF

touch /var/log/slideshow.log
chown pi:pi /var/log/slideshow.log

systemctl daemon-reload
systemctl enable slideshow.service controller.service

# ---------------------------------------------------------------------
log "Step 7/8: midnight cron job (next photo)"
# ---------------------------------------------------------------------
existing_cron="$(crontab -u pi -l 2>/dev/null || true)"
if echo "$existing_cron" | grep -q '/tmp/frame_ctl'; then
    echo "Cron entry already present, skipping."
else
    { echo "$existing_cron"; echo '0 0 * * * /bin/echo "next" > /tmp/frame_ctl 2>> /var/log/slideshow.log'; } \
        | crontab -u pi -
    echo "Installed midnight 'next' cron job for user pi."
fi

# ---------------------------------------------------------------------
log "Step 8/8: swapfile (512MB RAM is tight)"
# ---------------------------------------------------------------------
if [[ -f /swapfile ]] || swapon --show | grep -q swapfile; then
    echo "Swapfile already present, skipping."
else
    fallocate -l 512M /swapfile && chmod 600 /swapfile
    mkswap /swapfile && swapon /swapfile
    echo '/swapfile none swap sw 0 0' >> /etc/fstab
    echo "512MB swapfile enabled."
fi

# ---------------------------------------------------------------------
log "Done."
# ---------------------------------------------------------------------
echo "Reboot now to bring up the graphical slideshow: sudo reboot"
echo "After reboot, verify with:"
echo "  systemctl is-active slideshow.service controller.service"
echo "  pgrep -a feh"
echo
echo "Next: run 2-setup-ssh.sh (if you haven't already) so you can manage"
echo "this device remotely, then 3-setup-webserver.sh for the web panel."
