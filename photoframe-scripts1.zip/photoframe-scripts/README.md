# BPI-P2 Zero Photo Frame — Scripted Setup

## Run order

```
1-setup-after-sd-boot.sh   # on the device, right after first SD boot
2-setup-ssh.sh              # on the device, enables SSH + prints its IP
3-setup-webserver.sh        # from Windows via SSH, publishes the web panel
```

All three are self-contained — each one embeds every file it deploys
(scripts, systemd units, the Flask app) via heredocs, so copying just the
`.sh` file to the device and running it as root is enough. Every step is
idempotent; re-running a script skips anything already in place.

**No router access needed.** Script 3 publishes the web panel with
[Tailscale Funnel](https://tailscale.com/kb/1223/funnel) instead of
port-forwarding + DuckDNS + certbot — you get a public `https://...ts.net`
URL without ever touching your router's admin page.

One manual, one-time step before running script 3: sign in at
https://login.tailscale.com/admin/dns and turn on **HTTPS Certificates**
for your tailnet if it isn't already on. Funnel won't work without it —
this is a setting on your Tailscale account, not something a script on
the device can flip for you.

## `reference/`

Not needed to run anything — this folder holds a plain-file copy of
everything the scripts above embed and deploy, so you can read or diff
it without opening a heredoc:

```
reference/
├── device/
│   ├── slideshow.sh     # deployed to /home/pi/slideshow.sh by script 1
│   └── controller.sh    # deployed to /home/pi/controller.sh by script 1
├── webapp/
│   ├── app.py            # deployed to /home/pi/webapp/app.py by script 3
│   └── requirements.txt
└── systemd/
    ├── slideshow.service   # script 1
    ├── controller.service  # script 1
    └── webapp.service      # script 3 (gunicorn, binds 127.0.0.1:5000)
```

If you ever need to hand-edit something on the device instead of
re-running a script, these are the exact same contents to copy over.

## What each script does

**1-setup-after-sd-boot.sh** — creates the `pi` user, `apt` update/upgrade,
optional (confirmed, non-blind) eMMC clone, installs Xorg + feh, deploys
`slideshow.sh`/`controller.sh`, installs + enables `slideshow.service` and
`controller.service`, installs the midnight "next" cron job, adds a
512MB swapfile. Also sets `graphical.target` as the boot default, which
this Armbian image doesn't do on its own — without it `slideshow.service`
(`WantedBy=graphical.target`) would never start at boot.

**2-setup-ssh.sh** — installs/enables `openssh-server`, opens the port in
`ufw` if it's active, prints the device's IP address(es) with ready-to-use
`ssh pi@<ip>` lines for Windows (PowerShell, Windows Terminal, or PuTTY).

**3-setup-webserver.sh** — installs Tailscale and connects the device to
your tailnet (prints a login URL to open on your phone/PC), deploys the
Flask control panel (login, gallery, upload, delete, Next/Skip) behind
gunicorn on `127.0.0.1:5000`, then runs `tailscale funnel --bg 5000` to
publish it at a public `https://<device>.<tailnet>.ts.net` URL — reachable
from any browser, no app install needed on the viewing device, no router
changes, no port forwarding.
