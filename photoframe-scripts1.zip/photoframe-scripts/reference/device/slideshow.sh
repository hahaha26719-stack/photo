#!/bin/bash
#
# slideshow.sh — launches feh full-screen against a single symlink.
# controller.sh (separate service) owns repointing that symlink and
# telling feh to redraw via feh's own --control-pipe ("reload"), in
# response to "next" / "skip" commands sent to /tmp/frame_ctl.
# feh itself is never killed or restarted — no flicker.

set -euo pipefail

PHOTO_DIR="/home/pi/photos"
LINK_DIR="/home/pi/slideshow_link"
CURRENT_LINK="$LINK_DIR/current.jpg"
STATE_FILE="/home/pi/.slideshow_current"   # filename of the last-shown real photo
PIPE="/tmp/feh_pipe"
LOGFILE="/var/log/slideshow.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOGFILE"
}

mkdir -p "$PHOTO_DIR" "$LINK_DIR"

if [[ -p "$PIPE" ]]; then
    log "Control pipe already exists at $PIPE"
elif [[ -e "$PIPE" ]]; then
    log "ERROR: $PIPE exists and is not a FIFO. Removing and recreating."
    rm -f "$PIPE"
    mkfifo "$PIPE"
else
    mkfifo "$PIPE"
    log "Created control pipe at $PIPE"
fi
chmod 660 "$PIPE"

unclutter -idle 0.1 -root &

while [[ -z "$(find "$PHOTO_DIR" -maxdepth 1 -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) -print -quit)" ]]; do
    log "No photos found yet in $PHOTO_DIR — waiting..."
    sleep 5
done

# --- Initialize the symlink on boot/first run: resume where we left off ---
if [[ ! -L "$CURRENT_LINK" ]]; then
    target=""
    if [[ -f "$STATE_FILE" ]]; then
        last="$(cat "$STATE_FILE")"
        [[ -f "$PHOTO_DIR/$last" ]] && target="$PHOTO_DIR/$last"
    fi
    if [[ -z "$target" ]]; then
        target="$(find "$PHOTO_DIR" -maxdepth 1 -type f \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) | sort | head -n1)"
    fi
    ln -sf "$target" "$CURRENT_LINK"
    log "Initialized $CURRENT_LINK -> $(readlink "$CURRENT_LINK")"
fi

log "Starting feh on $CURRENT_LINK"

exec feh \
    --fullscreen \
    --hide-pointer \
    --auto-zoom \
    --control-pipe "$PIPE" \
    --no-menus \
    --quiet \
    "$CURRENT_LINK"
