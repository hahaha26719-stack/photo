#!/bin/bash
#
# controller.sh — owns /tmp/frame_ctl. Understands two commands:
#   next  -> advance to the next photo in sorted-filename order (wraps
#            after the last one). Robust to gaps left by web-UI deletes.
#   skip  -> show the black image (does NOT consume a slot in the
#            sequence; the next "next" resumes from where it left off)
#
# On each command it repoints the CURRENT_LINK symlink, then writes
# "reload" into feh's own --control-pipe so feh redraws in-process.
# feh is never killed or restarted.

set -euo pipefail

PHOTO_DIR="/home/pi/photos"
BLACK_IMAGE="/home/pi/black/black.jpg"
CURRENT_LINK="/home/pi/slideshow_link/current.jpg"
STATE_FILE="/home/pi/.slideshow_current"   # stores the last real photo FILENAME
FRAME_CTL="/tmp/frame_ctl"
FEH_PIPE="/tmp/feh_pipe"
LOGFILE="/var/log/slideshow.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [controller] $*" >> "$LOGFILE"
}

mkdir -p "$PHOTO_DIR" "$(dirname "$BLACK_IMAGE")" "$(dirname "$CURRENT_LINK")"

if [[ ! -f "$BLACK_IMAGE" ]]; then
    if command -v convert >/dev/null 2>&1; then
        convert -size 1920x1080 xc:black "$BLACK_IMAGE"
        log "Generated black image at $BLACK_IMAGE"
    else
        log "ERROR: no black.jpg and ImageMagick not installed. Place a black image at $BLACK_IMAGE manually."
    fi
fi

if [[ ! -p "$FRAME_CTL" ]]; then
    [[ -e "$FRAME_CTL" ]] && rm -f "$FRAME_CTL"
    mkfifo "$FRAME_CTL"
    log "Created $FRAME_CTL"
fi
chmod 660 "$FRAME_CTL"

reload_feh() {
    if [[ -p "$FEH_PIPE" ]]; then
        echo "reload" > "$FEH_PIPE"
    else
        log "WARNING: $FEH_PIPE not found — is slideshow.service running?"
    fi
}

do_next() {
    mapfile -t files < <(find "$PHOTO_DIR" -maxdepth 1 -type f \
        \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) | sort)
    local total="${#files[@]}"
    if [[ "$total" -eq 0 ]]; then
        log "No photos in $PHOTO_DIR — ignoring 'next'"
        return
    fi

    local last="" idx=-1
    [[ -f "$STATE_FILE" ]] && last="$(cat "$STATE_FILE")"

    if [[ -n "$last" ]]; then
        for i in "${!files[@]}"; do
            [[ "${files[$i]}" == "$PHOTO_DIR/$last" ]] && idx="$i" && break
        done
    fi

    local next_idx=$(( (idx + 1) % total ))
    local next_file="${files[$next_idx]}"

    ln -sf "$next_file" "$CURRENT_LINK"
    basename "$next_file" > "$STATE_FILE"
    log "next -> $(basename "$next_file") ($((next_idx + 1))/$total)"
    reload_feh
}

do_skip() {
    ln -sf "$BLACK_IMAGE" "$CURRENT_LINK"
    log "skip -> black image (sequence position unchanged)"
    reload_feh
}

log "Controller listening on $FRAME_CTL"

exec 3<>"$FRAME_CTL"
while read -r cmd <&3; do
    case "$cmd" in
        next) do_next ;;
        skip) do_skip ;;
        "")   : ;;
        *)    log "Unknown command: '$cmd' (expected 'next' or 'skip')" ;;
    esac
done
