#!/bin/bash
#
# 3-setup-webserver.sh
#
# Run this ON THE DEVICE (e.g. via the SSH connection from 2-setup-ssh.sh),
# as root. Sets up the photo frame's web control panel (login, gallery,
# upload, delete, Next/Skip) and publishes it to a public HTTPS URL using
# Tailscale Funnel — no router access, port forwarding, or DuckDNS needed.
#
# One-time manual step (can't be scripted — it's a web action on your
# Tailscale account, not the device): before running this script, sign in
# at https://login.tailscale.com/admin/dns and turn on "HTTPS Certificates"
# for your tailnet if it isn't already on. Funnel won't work without it.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run this as root (sudo -i, or 'sudo bash $0')." >&2
    exit 1
fi

echo "=== Web panel setup (via Tailscale Funnel) ==="
read -rp "Device name on your tailnet [default: $(hostname)]: " TS_HOSTNAME
TS_HOSTNAME="${TS_HOSTNAME:-$(hostname)}"

# ---------------------------------------------------------------------
echo -e "\n==> Step 1/5: install Tailscale"
# ---------------------------------------------------------------------
if ! command -v tailscale >/dev/null 2>&1; then
    curl -fsSL https://tailscale.com/install.sh | sh
fi

if ! tailscale status &>/dev/null; then
    echo
    echo "Running 'tailscale up' — it will print a login URL below."
    echo "Open that URL on your phone or PC to authorize this device."
    echo
    tailscale up --hostname="$TS_HOSTNAME"
else
    echo "Tailscale already connected."
fi

tailscale status

# ---------------------------------------------------------------------
echo -e "\n==> Step 2/5: Flask app"
# ---------------------------------------------------------------------
apt update
apt install -y python3-venv

mkdir -p /home/pi/webapp/templates

cat > /home/pi/webapp/requirements.txt <<'EOF'
Flask==3.0.3
gunicorn==22.0.0
Werkzeug==3.0.3
EOF

cat > /home/pi/webapp/app.py <<'APP_EOF'
"""
app.py — Photo frame control panel.

Single-user, password-protected web UI:
  - Login (session cookie, password stored as a hash — never plaintext)
  - Gallery: view / upload / delete photos
  - Next / Skip buttons -> write directly to the frame's control FIFO

Run behind gunicorn — Tailscale Funnel handles TLS termination, so this
app itself is only ever reached on 127.0.0.1.
"""

import os
import re
import secrets
from pathlib import Path
from functools import wraps

from flask import (
    Flask, request, redirect, url_for, session,
    render_template_string, send_from_directory, abort, flash
)
from werkzeug.security import check_password_hash
from werkzeug.utils import secure_filename

PHOTO_DIR = Path("/home/pi/photos")
CURRENT_LINK = Path("/home/pi/slideshow_link/current.jpg")
FRAME_CTL = "/tmp/frame_ctl"
ALLOWED_EXT = {"jpg", "jpeg", "png"}

app = Flask(__name__)
# SECRET_KEY and PASSWORD_HASH are read from environment variables set in
# the systemd unit's EnvironmentFile — never hardcode secrets in source.
app.config["SECRET_KEY"] = os.environ["FRAME_SECRET_KEY"]
PASSWORD_HASH = os.environ["FRAME_PASSWORD_HASH"]

PHOTO_DIR.mkdir(parents=True, exist_ok=True)


# ---------- auth ----------

def login_required(f):
    @wraps(f)
    def wrapped(*a, **kw):
        if not session.get("authed"):
            return redirect(url_for("login", next=request.path))
        return f(*a, **kw)
    return wrapped


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]


def check_csrf():
    token = request.form.get("csrf", "")
    if not token or token != session.get("csrf"):
        abort(400, "Bad CSRF token")


LOGIN_ATTEMPTS = {}  # ip -> failed attempt count (simple in-memory throttle)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        ip = request.remote_addr
        if LOGIN_ATTEMPTS.get(ip, 0) >= 10:
            return render_template_string(LOGIN_HTML, error="Too many attempts. Wait a while."), 429
        if check_password_hash(PASSWORD_HASH, request.form.get("password", "")):
            session.clear()
            session["authed"] = True
            LOGIN_ATTEMPTS.pop(ip, None)
            return redirect(request.args.get("next") or url_for("gallery"))
        LOGIN_ATTEMPTS[ip] = LOGIN_ATTEMPTS.get(ip, 0) + 1
        return render_template_string(LOGIN_HTML, error="Wrong password."), 401
    return render_template_string(LOGIN_HTML, error=None)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------- helpers ----------

def sorted_photos():
    return sorted(
        p.name for p in PHOTO_DIR.iterdir()
        if p.is_file() and p.suffix.lower().lstrip(".") in ALLOWED_EXT
    )


def next_filename(ext):
    existing = sorted_photos()
    nums = [int(m.group(1)) for n in existing if (m := re.match(r"^(\d+)\.", n))]
    n = (max(nums) + 1) if nums else 1
    return f"{n:03d}.{ext}"


def current_photo_name():
    try:
        return CURRENT_LINK.resolve().name
    except (OSError, RuntimeError):
        return None


def send_frame_command(cmd):
    # Non-blocking-ish write to the FIFO; controller.sh is always reading it.
    try:
        with open(FRAME_CTL, "w") as f:
            f.write(cmd + "\n")
        return True
    except OSError:
        return False


# ---------- routes ----------

@app.route("/")
@login_required
def gallery():
    photos = sorted_photos()
    current = current_photo_name()
    return render_template_string(
        GALLERY_HTML, photos=photos, current=current, csrf=csrf_token()
    )


@app.route("/photos/<path:filename>")
@login_required
def serve_photo(filename):
    return send_from_directory(PHOTO_DIR, filename)


@app.route("/upload", methods=["POST"])
@login_required
def upload():
    check_csrf()
    files = request.files.getlist("photo")
    if not files or files[0].filename == "":
        flash("No file selected.")
        return redirect(url_for("gallery"))

    for f in files:
        filename = secure_filename(f.filename)
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext not in ALLOWED_EXT:
            continue
        dest = PHOTO_DIR / next_filename(ext)
        f.save(dest)

    return redirect(url_for("gallery"))


@app.route("/delete/<path:filename>", methods=["POST"])
@login_required
def delete(filename):
    check_csrf()
    filename = secure_filename(filename)
    target = PHOTO_DIR / filename
    if target.exists() and target.parent == PHOTO_DIR:
        was_current = current_photo_name() == filename
        target.unlink()
        if was_current:
            # The photo on screen just vanished — advance immediately so
            # the frame isn't left pointing at a dead symlink.
            send_frame_command("next")
    return redirect(url_for("gallery"))


@app.route("/frame/<cmd>", methods=["POST"])
@login_required
def frame_command(cmd):
    check_csrf()
    if cmd not in ("next", "skip"):
        abort(400)
    ok = send_frame_command(cmd)
    flash("Sent." if ok else "Controller not responding — is controller.service running?")
    return redirect(url_for("gallery"))


# ---------- templates ----------

LOGIN_HTML = """
<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Photo Frame Login</title>
<style>
body{font-family:sans-serif;background:#111;color:#eee;display:flex;height:100vh;
     align-items:center;justify-content:center;margin:0}
form{background:#1c1c1c;padding:2rem;border-radius:10px;width:280px}
input{width:100%;padding:.6rem;margin-top:.5rem;border-radius:6px;border:1px solid #444;
      background:#000;color:#eee;box-sizing:border-box}
button{width:100%;padding:.6rem;margin-top:1rem;border-radius:6px;border:0;
       background:#3b82f6;color:#fff;font-weight:bold}
.err{color:#f87171;margin-top:.5rem}
</style></head><body>
<form method="post">
  <h2>Photo Frame</h2>
  <input type="password" name="password" placeholder="Password" autofocus required>
  <button type="submit">Log in</button>
  {% if error %}<div class="err">{{ error }}</div>{% endif %}
</form></body></html>
"""

GALLERY_HTML = """
<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Photo Frame</title>
<style>
body{font-family:sans-serif;background:#111;color:#eee;margin:0;padding:1rem}
h1{font-size:1.2rem}
.controls{display:flex;gap:.5rem;margin-bottom:1rem;flex-wrap:wrap}
.controls form{margin:0}
button{padding:.6rem 1rem;border:0;border-radius:6px;background:#3b82f6;color:#fff;
       font-weight:bold;cursor:pointer}
button.skip{background:#374151}
button.del{background:#7f1d1d;padding:.3rem .6rem;font-size:.75rem}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:.6rem}
.card{background:#1c1c1c;border-radius:8px;overflow:hidden}
.card img{width:100%;height:90px;object-fit:cover;display:block}
.card .meta{padding:.4rem;font-size:.75rem;display:flex;justify-content:space-between;align-items:center}
.current{outline:3px solid #22c55e}
.upload{margin:1rem 0}
a{color:#93c5fd}
.flash{background:#374151;padding:.5rem;border-radius:6px;margin-bottom:1rem}
</style></head><body>

<h1>Photo Frame</h1>

{% with messages = get_flashed_messages() %}
  {% for m in messages %}<div class="flash">{{ m }}</div>{% endfor %}
{% endwith %}

<div class="controls">
  <form method="post" action="{{ url_for('frame_command', cmd='next') }}">
    <input type="hidden" name="csrf" value="{{ csrf }}">
    <button type="submit">▶ Next</button>
  </form>
  <form method="post" action="{{ url_for('frame_command', cmd='skip') }}">
    <input type="hidden" name="csrf" value="{{ csrf }}">
    <button class="skip" type="submit">⬛ Skip (black)</button>
  </form>
  <a href="{{ url_for('logout') }}"><button type="button" class="skip">Log out</button></a>
</div>

<form class="upload" method="post" action="{{ url_for('upload') }}" enctype="multipart/form-data">
  <input type="hidden" name="csrf" value="{{ csrf }}">
  <input type="file" name="photo" accept="image/jpeg,image/png" multiple required>
  <button type="submit">Upload</button>
</form>

<div class="grid">
  {% for p in photos %}
  <div class="card {{ 'current' if p == current else '' }}">
    <img src="{{ url_for('serve_photo', filename=p) }}" loading="lazy">
    <div class="meta">
      <span>{{ p }}</span>
      <form method="post" action="{{ url_for('delete', filename=p) }}"
            onsubmit="return confirm('Delete {{ p }}?')">
        <input type="hidden" name="csrf" value="{{ csrf }}">
        <button class="del" type="submit">✕</button>
      </form>
    </div>
  </div>
  {% endfor %}
</div>

</body></html>
"""

if __name__ == "__main__":
    # Local dev only — production runs via gunicorn (see webapp.service)
    app.run(host="127.0.0.1", port=5000)
APP_EOF

python3 -m venv /home/pi/webapp/venv
/home/pi/webapp/venv/bin/pip install --quiet -r /home/pi/webapp/requirements.txt

# ---------------------------------------------------------------------
echo -e "\n==> Step 3/5: login password + secret key"
# ---------------------------------------------------------------------
echo "Choose the password you'll log into the web panel with."
SECRETS_OUT="$(/home/pi/webapp/venv/bin/python3 - <<'PYEOF'
import secrets, getpass
from werkzeug.security import generate_password_hash

password = getpass.getpass("Choose the photo-frame login password: ")
confirm = getpass.getpass("Confirm password: ")
if password != confirm:
    raise SystemExit("Passwords didn't match — run again.")

print(f"FRAME_SECRET_KEY={secrets.token_hex(32)}")
print(f"FRAME_PASSWORD_HASH={generate_password_hash(password)}")
PYEOF
)"

printf '%s\n' "$SECRETS_OUT" > /home/pi/webapp/webapp.env
chmod 600 /home/pi/webapp/webapp.env
chown -R pi:pi /home/pi/webapp
echo "webapp.env written."

# ---------------------------------------------------------------------
echo -e "\n==> Step 4/5: webapp.service (gunicorn)"
# ---------------------------------------------------------------------
cat > /etc/systemd/system/webapp.service <<'EOF'
[Unit]
Description=Photo frame web control panel (gunicorn)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=pi
Group=pi
WorkingDirectory=/home/pi/webapp
EnvironmentFile=/home/pi/webapp/webapp.env
# Bind to localhost only — Tailscale Funnel is the only thing that should
# reach this directly; the public internet reaches Funnel, never gunicorn.
ExecStart=/home/pi/webapp/venv/bin/gunicorn \
    --workers 2 \
    --bind 127.0.0.1:5000 \
    --timeout 60 \
    app:app
Restart=on-failure
RestartSec=5
StandardOutput=append:/var/log/webapp.log
StandardError=append:/var/log/webapp.log

[Install]
WantedBy=multi-user.target
EOF

touch /var/log/webapp.log
chown pi:pi /var/log/webapp.log

systemctl daemon-reload
systemctl enable --now webapp.service

# ---------------------------------------------------------------------
echo -e "\n==> Step 5/5: publish with Tailscale Funnel"
# ---------------------------------------------------------------------
sleep 2
echo "Local check (should redirect to /login):"
curl -Is http://127.0.0.1:5000/ | head -n 1 || true

# Persists across reboots — tailscaled restores serve/funnel config on start.
tailscale funnel --bg 5000

echo
echo "-----------------------------------------------------------------"
echo "Funnel status:"
tailscale funnel status
echo
echo "If the URL above didn't appear, it's almost always because HTTPS"
echo "Certificates aren't enabled for your tailnet yet — turn it on at:"
echo "  https://login.tailscale.com/admin/dns"
echo "then re-run: tailscale funnel --bg 5000"
echo
echo "Open the printed https://....ts.net URL from any device, anywhere —"
echo "no app required on the viewing device, no router changes needed."
echo "-----------------------------------------------------------------"
